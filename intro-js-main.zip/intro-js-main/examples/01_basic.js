// Esto es un comentario

// Esto es un comentario 2

/*
comentarios en
varias lineas
*/

// variables
var edad = 20;
var saludo = 'Hola a todos';

console.log(edad);
console.log(saludo);

// cammelCase
const esMayorDeEdad = 21;
// const no se pueden asignar otra vez
// esMayorEdad = 10;

let nombre = 'Usuario 1';

console.log(nombre); // Usuario 1

nombre = 'Usuario 2';

console.log(nombre); // Usuario 2

console.log(esMayorDeEdad);

let isActive = true;

nombre = 12;

// Typescript

console.log(nombre);

const NUMBER_PI = 3.1416;
